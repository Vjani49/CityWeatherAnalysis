﻿using System;
using System.IO;
using System.Net;

namespace CityWeatherAnalysis
{
    class Program
    {
        static private string cityNamesData = @"E:\Prudential\InputFolder\City\Data.txt";
        private static readonly string URL = "http://api.openweathermap.org/data/2.5/group";
        private static readonly string appID = "aa69195559bd4f88d79f9aadeb77a8f6";
        private static readonly string queryParameterID = "?id=";
        private static readonly string queryParameterAppID = "&units=metric&appid=";
        static private string outputFilePath = @"E:\Prudential\OutputFolder\";
        static private string currentDate;

        static void Main(string[] args)
        {
            // Read a text file line by line.
            string[] CityLineItem = File.ReadAllLines(cityNamesData);
            currentDate = DateTime.Now.ToString("M/d/yyyy");
            currentDate = currentDate.Replace('/','-');

            // Get Count of Cities
            int CityCount = CityLineItem.Length;

            // Create Array to store City Names and City IDs
            string[] CityName = new string[CityCount];
            int[] CityID = new int[CityCount];

            // Create an Iterator to be used across loops for counts
            int Iterator = 0;
            string[] CityDetails = new string[2];

            foreach (string city in CityLineItem)
            {
                CityDetails = city.Split('=');
                
                CityID[Iterator] = int.Parse(CityDetails[0]);
                CityName[Iterator++] = CityDetails[1];
                
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + queryParameterID + CityDetails[0] + queryParameterAppID + appID);
                try
                {
                    WebResponse response = request.GetResponse();
                    using (Stream responseStream = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.UTF8);
                        
                        if (!Directory.Exists(outputFilePath + @"\" + CityDetails[1]))
                        {
                            Console.WriteLine(currentDate);
                            Directory.CreateDirectory(outputFilePath + @"\" + CityDetails[1]);
                        }

                        File.WriteAllText(outputFilePath + @"\" + CityDetails[1] + @"\" + CityDetails[1] +"_" + currentDate + ".json", reader.ReadToEnd());

                    }
                }
                catch (WebException ex)
                {
                    WebResponse errorResponse = ex.Response;
                    using (Stream responseStream = errorResponse.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.GetEncoding("utf-8"));
                        String errorText = reader.ReadToEnd();
                        // log errorText
                    }
                    throw;
                }

            }

            char c = Console.ReadKey().KeyChar;
        }
    }
}
